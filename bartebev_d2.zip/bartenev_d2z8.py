"""
Напишите функцию sqspiral_rec(a), которая рисует «квадратную спираль» рекурсивно, а — длина наибольшего звена. 
"""

from turtle import *

def sqspiral_rec(a):
    if(a > 0):
        forward(a)
        left(90)
        forward(a)
        left(90)
        sqspiral_rec(a-5)
    else:
        return

sqspiral_rec(100)
mainloop()
bye()
