"""
Дано натуральное число N. Вычислите сумму его цифр. 
"""

def f(N):
    if(N // 10 == 0):
        return N
    else:
        return N % 10 + f(N // 10)

print(f(154))