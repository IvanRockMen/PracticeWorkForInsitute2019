"""
Написать функцию fib(n), которая вычисляет n-ый элемент последовательности чисел Фибоначчи.
"""

def fib(n):
    if(n == 1 or n == 2):
        return 1
    else:
        return fib(n-1) + fib(n-2)
    
print(fib(5))