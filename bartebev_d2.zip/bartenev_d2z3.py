"""
Написать функцию для вычисления суммы 12 +22 +⋯+𝑛2.
"""

def sqsum(n):
    if(n == 1):
        return 1
    else:
        return n*n+sqsum(n-1)

print(sqsum(10))