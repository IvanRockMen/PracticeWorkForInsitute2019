"""
Написать рекуррентную функцию fib_memo(n) вычисления nого элемента последовательности чисел Фибоначчи с памятью
"""

def fib_memo(n):
    if(n == 1 or n == 2):
        return 1
    else:
        return fib_memo(n-1) + fib_memo(n - 2)

mem = fib_memo(8)

print(mem)