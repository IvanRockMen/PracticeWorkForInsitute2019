"""
Написать функцию power(a, n), которая вычисляет 𝒂𝒏, где 𝒂 — вещественное число, 𝒏 ≥ 𝟎 — целое число. 
"""

def power(a, n):
    if(n == 0):
        return 1
    else:
        return a*power(a, n-1)

print(power(2, 10))
