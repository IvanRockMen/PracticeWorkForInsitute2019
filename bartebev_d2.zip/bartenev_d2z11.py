"""
 Нарисуйте снежинку Коха.
"""
from turtle import *

def koh(a, n):
    if(n == 0):
        forward(a)
        return
    a /= 3
    koh(a, n-1)
    left(60)
    koh(a, n-1)
    right(120)
    koh(a, n-1)
    left(60)
    koh(a, n-1)

for i in range(3):
    koh(100, 3)
    right(120)

mainloop()
bye()
