"""
Написать функцию sqrt(a, n), которая вычисляет квадратный корень из числа a по формуле
"""

def sqrt(a, n):
    if(n == 1):
        return a
    else:
        x = sqrt(a, n-1)
        return 0.5*(x+a/x)

print(sqrt(32, 5))