"""
Используя модуль turtle, нарисуйте кривую Коха.
"""
from turtle import *

def koh(a, n):
    if(n == 0):
        forward(a)
        return
    a /= 3
    koh(a, n-1)
    left(60)
    koh(a, n-1)
    right(120)
    koh(a, n-1)
    left(60)
    koh(a, n-1)


koh(100, 3)
mainloop()
bye()