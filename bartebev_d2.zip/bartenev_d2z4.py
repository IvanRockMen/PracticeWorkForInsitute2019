"""
Написать функцию для вычисления числа 𝜋 с помощью ряда Лейбница:
"""
def getPi(n):
    if(n == 0):
        return 4
    else:
        return 4*(-1)**n/(2*n+1)+getPi(n-1)

print(getPi(900))