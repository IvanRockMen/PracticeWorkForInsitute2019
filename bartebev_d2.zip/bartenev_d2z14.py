"""
Реализовать алгоритм быстрого возведения в степень
"""

def fast_pow(a, n):
    if(n % 2 == 0 and n != 0):
        return fast_pow(a, n/2)**2
    elif(n != 0):
        return a*fast_pow(a, n-1)
    else:
        return 1

print(fast_pow(2, 10))