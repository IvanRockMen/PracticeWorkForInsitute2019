"""
Дано натуральное число N. Выведите все его цифры в обратном порядке через пробел.
"""

def crazyPrinter(N):
    if(len(str(N)) == 1):
        print(N, end = ' ')
    else:
        print(N % 10, end = ' ')
        crazyPrinter(N // 10)

crazyPrinter(102)