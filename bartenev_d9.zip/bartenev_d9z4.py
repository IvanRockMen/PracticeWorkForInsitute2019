import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

fig = plt.figure()
ax = plt.axes(xlim  = (0, 2), ylim = (-10, 10))
line, = ax.plot([], [])
ax.grid()

def redraw(t):
    x = np.arange(0, 2, 0.1)

    y = (6/np.pi)*np.sin(np.pi*t/2)*np.sin(np.pi*x/2) + (4/np.pi)*np.sin(3*np.pi*t/2)*np.sin(3*np.pi*x/2)
    line.set_data(x, y)
    return line,

anim = FuncAnimation(fig, redraw, frames=10, interval = 20, blit = True)
plt.show()