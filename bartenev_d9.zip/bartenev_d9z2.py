import matplotlib.pyplot as plt
import numpy as np

points = []
def mouse_btn_down(event):
    points.append(ax.scatter(event.xdata, event.ydata, c='g'))
    fig.canvas.draw()

def space_btn_down(event):
    if(event.key == ' '):
        for i in range(len(points)):
            points[i].set_color('b')
        fig.canvas.draw()

fig = plt.figure()
fig.canvas.mpl_connect('button_press_event', mouse_btn_down)
fig.canvas.mpl_connect('key_press_event', space_btn_down)
ax = plt.axes(xlim = (-5, 5), ylim = (-5, 5))
ax.set_aspect('equal')
plt.show()