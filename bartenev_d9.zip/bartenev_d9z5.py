import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

fig = plt.figure() 
ax = plt.axes(xlim=(0, 100), ylim=(-10, 10)) 
line, = ax.plot([], []) 
ax.grid() 
 
def redraw(t):
    t = np.linspace(0, t, 1000)
    a = 1
    x = a*(t-np.sin(t))
    y = a*(1-np.cos(t))
    line.set_data(x, y) 
    return line, 
 
# результат обязательно присваивается переменной 
anim = FuncAnimation(fig, redraw, frames=100,                  
                                         interval=20, blit=True) 
plt.show()