import matplotlib.pyplot as plt 
 
fig = plt.figure()
plt.suptitle('АНАЛИЗ ФУНКЦИИ $w = w(z)$')
plt.subplots_adjust(wspace = 0.4) 
 
ax_z = fig.add_subplot(121)
ax_z.grid()
ax_z.axis('square')
ax_z.set_xlim((-10, 10))
ax_z.set_ylim((-10, 10))
ax_z.set_xlabel('$Re(z)$')
ax_z.set_ylabel('$Im(z)$')
ax_z.set_title('Прообраз, $z$') 
 
ax_w = fig.add_subplot(122)
ax_w.grid()
ax_w.axis('square')
ax_w.set_xlim((-10, 10))
ax_w.set_ylim((-10, 10))
ax_w.set_xlabel('$Re(w)$')
ax_w.set_ylabel('$Im(w)$')
ax_w.set_title('Образ, $w$') 
 
plt.show() 