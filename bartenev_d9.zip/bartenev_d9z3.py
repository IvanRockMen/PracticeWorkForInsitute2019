import matplotlib.pyplot as plt
import numpy as np



def axes_enter_mouse(event):
    x0, y0 = event.xdata, event.ydata
    a = y0/x0**2
    x = np.linspace(-10, 10, 1000)
    y = a*x**2
    plt.plot(x, y)
    fig.canvas.draw()


def axes_leave_mouse(event):
    ax.clear()
    fig.canvas.draw()



fig = plt.figure()
fig.canvas.mpl_connect('axes_enter_event', axes_enter_mouse)
fig.canvas.mpl_connect('axes_leave_event', axes_leave_mouse)
ax  = plt.axes(xlim = (-10, 10), ylim = (-10, 10))
ax.set_aspect('equal')
plt.show()

