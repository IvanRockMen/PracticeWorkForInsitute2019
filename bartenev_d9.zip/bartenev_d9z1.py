import matplotlib.pyplot as plt
import numpy as np

def on_btn_down(event):
    #print(event.xdata, event.ydata)
    print(np.hypot(event.xdata, event.ydata))
    x = np.array([0, event.xdata])
    y = np.array([0, event.ydata])
    plt.plot(x, y)
    fig.canvas.draw()


fig = plt.figure()

fig.canvas.mpl_connect('button_press_event', on_btn_down)
ax = plt.axes(xlim = (-5, 5), ylim = (-5,5))
ax.set_aspect('equal')
plt.show()