from turtle import *
        
        
def circ(r, x0, y0):
    up()
    goto(x0, y0)
    stamp()
    right(90)
    forward(r)
    left(90)
    down()
    circle(r)
circ(100, 1, 1)
mainloop()
bye()