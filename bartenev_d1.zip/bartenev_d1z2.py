"""
Напишите функцию poly (a, n), которая строит правильный nугольник со стороной a пикселей.
"""
from turtle import *

a = 100
n = 12
def poly(a, n):
    for i in range(n):
        forward(a)
        left(360/n)

poly(a, n)
mainloop()
bye()