"""
Напишите функцию spiral(n), которая принимает число n и рисует n витков спирали. 
"""

from turtle import *

def spiral(n):
    a = 10
    for i in range(n*10):
        forward(a)
        left(360//n)
        a += 2
spiral(10)
mainloop()
bye()

