"""
Напишите функцию poly2(R, n), которая строит правильный nугольник по радиусу описанной
окружности R.
"""
from turtle import *
from math import sin, pi

R = 5
n = 6

def poly2(R, n):
    a = 2*R*sin(pi/n)
    for i in range(n):
        forward(a)
        left(360/n)
        
poly2(R, n)
mainloop()
bye()