"""
Напишите функцию snowflake(n),
которая принимает число n и рисует
простую снежинку n-угольной
формы.
"""
from turtle import *

def snowflake(n):
    R = 50
    for i in range(n):
        up()
        goto(R, R)
        down()
        left(360//n)
        forward(R)
    
snowflake(7)
mainloop()
bye()