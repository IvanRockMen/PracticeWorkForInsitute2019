"""
Напишите функцию npoly(R, n, d),
которая рисует вложенные друг в
друга правильные n-угольники.
"""

from turtle import *
from math import sin, pi

def npoly(R, n, d):
    while R > 0:
        a = 2*R*sin(pi/n)
        for j in range(n):
            forward(a)
            left(360/n)
        up()
        left((180-(360//n))//2)
        forward(d)
        right((180-(360//n))//2)
        down()
        R -= d
        
npoly(100, 6, 10)
mainloop()
bye()            