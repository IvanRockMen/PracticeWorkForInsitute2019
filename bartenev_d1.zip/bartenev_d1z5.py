"""
Напишите функцию square_spiral(), которая рисует квадратную
спираль.
"""
from turtle import *

def square_spiral():
    a = 100
    for i in range(a):
        forward(a-i)
        left(90)

square_spiral()
mainloop()
bye()