"""
Напишите функцию squares(a), которая рисует вложенные друг в
друга квадраты.
"""
from turtle import *

def squares(a):
        global m
        m = 10
        while a > 0:
                for i in range(4):
                        forward(a)
                        left(90)
                up()
                forward(m)
                left(90)
                forward(m)
                right(90)
                down()
                a -= 2*m

squares(100)
mainloop()
bye()