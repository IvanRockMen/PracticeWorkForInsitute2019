"""
Напишите функцию square(a), которая строит квадрат со стороной a
пикселей.
"""
from turtle import *
a = 100
def square(a):
    for i in range(4):
        forward(a)
        left(90)
        
square(a)
mainloop()
bye()