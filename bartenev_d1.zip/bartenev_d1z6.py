"""
Напишите функцию star(n), которая
принимает целое число n>2 и рисует n-конечную звезду.
"""
from turtle import *

n = 6

def star(n):
    a = 100
    for i in range(n):
        right(60)
        forward(a)
        left(120)
        forward(a)
        right(60)
        left(360//n)
    
star(n)
mainloop()
bye()