f = open('Капитанская дочка.txt', 'r')
intext = f.read()
f.close()

for i in range(ord('А'), ord('я')+1):
    intext  = intext.replace(chr(i), '')

res = set(intext)
res = list(res)
newstr = ''
for i in range(len(res)):
    newstr += res[i]

print(newstr)
