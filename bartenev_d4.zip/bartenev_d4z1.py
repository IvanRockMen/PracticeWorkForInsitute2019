"""
Выполнить частотный анализ символов в тексте Капитанская дочка.txt. 
Результат отсортировать по убыванию частоты и сохранить в файл Символы.txt. Под частоту выделить поле из 6-ти позиций, незанятые позиции заполнить точками, далее следует символ.
"""
from collections import Counter

f = open('Капитанская дочка.txt', 'r')
intext = f.read()

f.close()

buf = Counter(intext).most_common()

f = open(file = 'Символы.txt', mode = 'w', encoding = 'utf-8')

for i in range(len(buf)):
    f.write('{frequency:.<6}{sym}\n'.format(frequency = (buf[i][1]), sym = buf[i][0]))

f.close()