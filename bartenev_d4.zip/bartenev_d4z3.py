def line(word):
    return len(word)

f = open('Капитанская дочка.txt', 'r')
intext = f.read()
f.close()

intext = intext.lower()

intext = intext.replace('–', ' ')
intext = intext.replace('\t', ' ')
intext = intext.replace('\n', ' ')
intext = intext.replace('.', '')
intext = intext.replace(',', '')
intext = intext.replace('"', '')
intext = intext.replace("'", '')
intext = intext.replace(':', '')
intext = intext.replace('-', '')
intext = intext.replace('?', '')
intext = intext.replace('!', '')
intext = intext.replace('...', '')
intext = intext.replace(';', '')
intext = intext.split(' ')
res = set(intext)
res = list(res)
res.sort(key = line, reverse = True)
for i in range(10):
    print(res[i] + ' ' + str(len(res[i])))