import sympy as s
from math import e

s.pprint(s.N(s.sqrt(2)))
s.pprint(s.N(s.pi**2))
s.pprint(s.N(s.sin(1)+s.cos(1)))
s.pprint(s.N(e**s.sin(s.sqrt(2))))