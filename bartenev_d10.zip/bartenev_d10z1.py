import sympy as s

x = s.Symbol('x')
y = s.Symbol('y')
z = s.Symbol('z')

s.pprint(s.expand((x+y-z)**3))
s.pprint(s.expand((x+y**2)*(x-3*y)*(x+s.sin(x))))