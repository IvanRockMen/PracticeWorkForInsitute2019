import sympy as s

x = s.Symbol('x')
y = s.Function('y')
y1 = s.diff(y(x), x)
y2 = s.diff(y(x), x, 2)

f = s.Eq(y2+2*y1+2*y(x), x*s.exp(-x))
s.pprint(s.dsolve(f, ics={y(0): 0, y(x).diff(x).subs(x, 0): 0}))
f = s.Eq(y2+y(x),2*x-s.pi)
s.pprint(s.dsolve(f, ics={y(0): 0, y(x).subs(x, s.pi): 0}))