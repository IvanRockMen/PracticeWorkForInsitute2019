import sympy as s

x = s.Symbol('x')

s.pprint(s.integrate(x**6, (x, 0, 1)))
s.pprint(s.integrate(x**3+(1/(x-1)), (x, 5, s.pi**2)))