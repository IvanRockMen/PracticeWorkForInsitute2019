import sympy as s

x = s.Symbol('x')
s.pprint(s.factor(x**4+5*x**2+4))
s.pprint(s.factor(x**5-6*x**4+9*x**3))
s.pprint(s.factor(x**3-3*x-2))
s.pprint(s.factor(x**6+64))