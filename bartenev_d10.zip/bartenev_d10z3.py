import sympy as s

x = s.Symbol('x')

s.pprint(s.apart((x**2+1)/(x*(x+1))))
s.pprint(s.apart((4*x+3)/(x*(x+1)*(x+2))))