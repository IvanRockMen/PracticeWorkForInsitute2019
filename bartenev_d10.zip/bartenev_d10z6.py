import sympy as s
from math import e

x = s.Symbol('x')

s.pprint(s.diff(x**2*e**x*s.cos(x)))
s.pprint(s.diff(x*s.sin(x)/s.tan(x)))