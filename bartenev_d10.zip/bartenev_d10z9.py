import sympy as s

x = s.Symbol('x')

sol = s.Eq(x**2+4*x+2, 0)

s.pprint(s.solve(sol))