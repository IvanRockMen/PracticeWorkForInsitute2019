import sympy as s

x = s.Symbol('x')

s.pprint(s.integrate(s.tan(x)))
s.pprint(s.integrate(s.ln(x)))