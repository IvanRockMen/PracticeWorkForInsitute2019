import sympy as s
from math import e

x = s.Symbol('x')

s.pprint(s.series(e**x))
s.pprint(s.series(s.sin(x)+2*e**x))