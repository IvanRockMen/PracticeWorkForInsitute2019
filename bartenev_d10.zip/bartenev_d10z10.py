import sympy as s

x = s.Symbol('x')

sol = s.Eq(x**5+4*x+2, 0)
sl = s.solve(sol)
s.pprint(s.evalf(sl))