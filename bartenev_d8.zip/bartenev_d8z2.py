import numpy as np
import matplotlib.pyplot as plt

t = np.arange(0, 2*np.pi, 0.1)
a = 1

x = a*(t-np.sin(t))
y = a*(1-np.cos(t))

plt.title('Циклоида')
plt.xlabel('x')
plt.ylabel('y')

plt.plot(x, y, '-.', c='g')
plt.show()