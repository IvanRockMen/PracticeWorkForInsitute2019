import numpy as np
import matplotlib.pyplot as plt

a1 = 0.9
a2 = 1.0
a3 = 1.2

x = np.arange(-3,3,0.5)
y1 = a1/2*(np.e**(x/a1) + np.e ** (x/a1))
y2 = a2/2*(np.e**(x/a2) + np.e ** (x/a2))
y3 = a3/2*(np.e**(x/a3) + np.e ** (x/a3))



line1 = plt.plot(x, y1, c='g', label = 'a = 0.9')
line2 = plt.plot(x, y2, c='b', label = 'a = 1.0')
line3 = plt.plot(x, y3, c='r', label = 'a = 1.2')
plt.legend()
plt.show()