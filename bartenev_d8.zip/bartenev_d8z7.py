import numpy as np
import matplotlib.pyplot as plt

from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

a = b = 1

t = np.arange(0, 20, 0.1)

x = a*np.cos(t)
y = a*np.sin(t)
z = b*t
x,y = np.meshgrid(x, y)

fig = plt.figure()
ax = fig.add_subplot(111, projection = '3d')
ax.plot_surface(x, y, z, cmap=cm.magma)
plt.show()
