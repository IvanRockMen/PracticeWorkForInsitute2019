import numpy as np
import matplotlib.pyplot as plt

from scipy.special import jv

x = np.arange(0, 20, 0.1)
y1 = jv(0, x)
y2 = jv(1, x)
y3 = jv(2, x)
plt.title('График функции Бесселя первого рода')
plt.plot(x, y1, c='r', label = 'J0(x)')
plt.plot(x, y2, '--', c='g', label = 'J1(x)')
plt.plot(x, y3, '-.', c='b', label = 'J2(x)')
plt.legend()
plt.show()