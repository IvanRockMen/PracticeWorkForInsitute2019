import numpy as np
import matplotlib.pyplot as plt

a = 1
fi = np.arange(0, 2*np.pi, 0.1)
r = a*(1-np.cos(fi))

plt.polar(fi, r)
plt.show()