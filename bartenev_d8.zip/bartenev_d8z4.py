import numpy as np
import matplotlib.pyplot as plt

from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

a = 1

x = np.arange(-3, 3, 0.1)
y = np.arange(-3, 3, 0.1)
z = x**3 + y**3 - 3*a*x*y

r = np.meshgrid(x, y)


plt.contour(x, z)

plt.show()
