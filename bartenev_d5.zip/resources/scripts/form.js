var i = 0;


function addrow(){
    var d = document.getElementById('row');
    var newrow = d.cloneNode(true);
    var newid = i+1;
    newid = newid.toString();
    i += 1;
    newrow.id = d.id + ' ' + newid;
    d.parentNode.insertBefore(newrow, d.nextSibling);
}

function removerow(){
    var d = document.getElementById('form');
    var all = d.getElementsByClassName('row');
    var deleting = all[all.length];
    d.removeChild(deleting);
}