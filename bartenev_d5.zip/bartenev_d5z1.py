import os
from PIL import Image
from numpy import average

def sortByLine(cort):
    return cort[2]

html = """
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="/resources/styles/bootstrap.min.css">
        <title>Расстояние Хофмана</title>
    </head>
    <body>
    <div class="container">

"""
N = 15

com = ['jpg', 'png', 'bmp']
img_hash = []
imgs_dist = []
dir_path = os.getcwd() + '/resources/'
photo_dir = dir_path + 'photos'
imgs = []
for top, dirs, files in os.walk(photo_dir):
    for nm in files:
        if(os.path.join(top, nm).split('.')[-1] in com):
            imgs.append(os.path.join(top, nm))


for i in range(len(imgs)):
    img = Image.open(imgs[i], 'r')
    img = img.resize((8, 8))
    img = img.convert('L')
    averaged = average(img.getdata())
    binary = (img.getdata()<averaged)
    hash = 0
    for ind, num in enumerate(binary):
        hash += int(num)*2**ind
    img_hash.append((imgs[i], hash))

for i in range(len(img_hash)):
    for j in range(i+1, len(img_hash)):
        l = bin(img_hash[i][1]^img_hash[j][1]).count('1')
        if(l <= N):
            imgs_dist.append((img_hash[i][0], img_hash[j][0], l))

imgs_dist.sort(key=sortByLine)
for i in range(len(imgs_dist)):
    html += '''<div class = "row mt-5">
    <div class="col-md-12">
    <p>Расстояние Хофмана: {r}</p>
    </div>
    <div class="row mt-5">
    <div class="col-md-6">
    <img src="{i1}">
    </div>
    <div class="col-md-6">
    <img src="{i2}">
    </div>
    </div>
    '''.format(r = imgs_dist[i][2], i1 = imgs_dist[i][0], i2 = imgs_dist[i][1])

html += '''
</div>
</body>
</html>
'''

f = open(file = 'index.html', mode='w', encoding = 'utf-8')
f.write(html)
f.close()