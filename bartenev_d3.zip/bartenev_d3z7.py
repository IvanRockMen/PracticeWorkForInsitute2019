"""
Написать программу, вычисляющую НОД и НОК двух целых чисел.
"""

a, b = map(int, input().split())
c, d = a , b
while a != 0 and b != 0:
    if(a > b):
        a = a % b
    else:
        b = b % a

nod = a + b
nok = nod / (c * d)
print(nod)
print(nok)