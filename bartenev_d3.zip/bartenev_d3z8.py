"""
Пользователь вводит целое число n≥2. Написать функцию is_prime(n), которая выводит True, если число простое и False, если число составное.
"""

def IsPrime(n):
    d = 2
    while n % d != 0:
        d += 1
    return d == n

print(IsPrime(int(input())))