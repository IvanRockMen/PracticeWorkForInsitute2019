from random import randint
from time import time

starttime = time()
startnum = randint(1, 1000)
trying = 0
a = 0
while a != startnum:
    a = int(input('Введите число, которое вы считаете ответом от 1 до 1000: '))
    if(a > startnum):
        print('Искомое число меньше')
        trying += 1
    elif(a < startnum):
        print('Искомое число больше')
        trying += 1
    else:
        print('Поздравляю вы победили')
        trying += 1

endtime = time()
delta = endtime - starttime
print('Попыток ' + str(trying))
print(str(delta) + ' sec')