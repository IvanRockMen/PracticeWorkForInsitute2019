"""
Пользователь вводит целое число 𝒏. Написать функцию next_prime(n), которая возвращает ближайшее простое число, следующее за 𝒏.
"""

def IsPrime(n):
    d = 2
    while n % d != 0:
        d += 1
    return d == n

def next_prime(n):
    n += 1
    while  not IsPrime(n):
        n += 1
    return n

print(next_prime(int(input())))