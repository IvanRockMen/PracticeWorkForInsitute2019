"""
Пользователь вводит текст, содержащий любые символы. Найти сумму всех имеющихся в тексте цифр.
"""

text = input('Введите текст: ')
res = 0
for i in range(len(text)):
    if(text[i].isdigit()):
        res += int(text[i])

print(res)