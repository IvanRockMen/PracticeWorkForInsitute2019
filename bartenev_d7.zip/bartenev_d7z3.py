import numpy as np
import matplotlib.pyplot as plt

X = np.arange(0, 10, 0.01)
Y = 5*np.e**(-2*X)*np.sin(np.pi*X)
fig, ax = plt.subplots()
ax.plot(X, Y)
plt.show()