import numpy as np

n, m = list(map(int, input().split()))
A = np.random.randint(low = -9, high = 9, size = (n, n))

while round(np.linalg.det(A)) != m:
    A = np.random.randint(low = -9, high = 9, size = (n, n))

print(A)