import numpy as np

A = np.linspace(start = 0, stop = 10, num = 11)

print(A)