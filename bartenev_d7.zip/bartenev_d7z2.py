import numpy as np
import matplotlib.pyplot as plt

B = np.arange(-2*np.pi, 2*np.pi, (10**-2)*np.e)

C = np.sin(B)

fig, ax = plt.subplots()
ax.plot(B, C)
plt.show()