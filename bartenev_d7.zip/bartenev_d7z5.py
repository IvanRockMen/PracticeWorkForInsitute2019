import numpy as np

A = np.array([[9, -5, -4], [8, -5, -3], [-3, -7, 6]])
B = np.array([6, 7, 8])

solve = np.linalg.solve(A, B)
print(solve)