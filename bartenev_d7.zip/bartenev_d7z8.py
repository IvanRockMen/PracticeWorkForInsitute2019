import numpy as np
import matplotlib.pyplot as plt

def f(x, y):
    return x**2 - 2*y


Y1 = [1.0]

h = 0.1

X = np.arange(0, 1, h)

for i in range(len(X)):
    Y1.append(float(Y1[i])+float(h*f(X[i], Y1[i])))

fig, ax = plt.subplots()

print(Y1)
Y2 = (3/4)*np.e**(-2*X) + (1/2)*X**2 - (1/2)*X+(1/4)
print(Y2)
ax.plot(X, Y1, c= 'r')
ax.plot(X, Y2, c= 'g')
ax.show()