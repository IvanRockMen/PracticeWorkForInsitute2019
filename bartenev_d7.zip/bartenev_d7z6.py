import numpy as np

A = np.array([[-1, 2, -3], [3, -4, 5], [1, -3, 4]])
B = np.array([[552, -373, 495], [-1656, 1305, -1771], [-896, 624, -832]])
counter = 0
R = np.eye(3)


while not np.all(R == B):
    R = R @ A
    counter += 1

print(counter)